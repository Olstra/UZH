<<<<<<< HEAD
print('Hello c')
=======
print('Hello c')
>>>>>>> develop
